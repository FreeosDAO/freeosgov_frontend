export default {
  balance: 0,
  unVestHistory: null,
  unVestPercentage: 0
}
