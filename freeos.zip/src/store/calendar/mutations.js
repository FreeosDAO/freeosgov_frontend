export function SET_NEXT_CALENDAR (state, payload) {
  state.nextCalender = payload
}

export function SET_CURRENT_CALENDAR (state, payload) {
  state.currentIteration = payload
}
