export default {
  currentIteration: {
    end_date: '',
    iteration_number: null
  },
  nextCalendar: ''
}
