/*
export function someGetter (state) {
}
*/
