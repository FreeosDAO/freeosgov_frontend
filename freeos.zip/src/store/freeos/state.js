import definition from './definition'

export default () => (definition)
