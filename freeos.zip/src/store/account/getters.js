export const isAuthenticated = ({ accountName }) => accountName !== null
export const connecting = ({ connecting }) => connecting
export const claimInfo = ({ claimInfo }) => claimInfo
