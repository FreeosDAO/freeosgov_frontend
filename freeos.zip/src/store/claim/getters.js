export const userPreviousBalance = ({ userPreviousBalance }) => userPreviousBalance
export const userAfterBalance = ({ userAfterBalance }) => userAfterBalance
export const isClaimed = ({ isClaimed }) => isClaimed
