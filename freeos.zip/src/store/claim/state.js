export default () => ({
  userPreviousBalance: '',
  userAfterBalance: '',
  isClaimed: false
})
