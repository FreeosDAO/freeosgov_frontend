export const setUserPreviousBalance = (state, balance) => {
  state.userPreviousBalance = balance
}

export const setUserAfterBalance = (state, balance) => {
  state.userAfterBalance = balance
}

export const setIsClaimed = (state, isClaimed) => {
  state.isClaimed = isClaimed
}
